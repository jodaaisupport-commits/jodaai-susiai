"use client";

import type { Message, Project } from "./types";

const PROJECTS = "susiai-projects";
const MESSAGES = "susiai-messages";
const PREFS = "susiai-preferences";

export function loadProjects(): Project[] {
  try { return JSON.parse(localStorage.getItem(PROJECTS) || "[]"); } catch { return []; }
}

export function saveProjects(projects: Project[]) {
  localStorage.setItem(PROJECTS, JSON.stringify(projects));
}

export function loadMessages(): Message[] {
  try { return JSON.parse(localStorage.getItem(MESSAGES) || "[]"); } catch { return []; }
}

export function saveMessages(messages: Message[]) {
  localStorage.setItem(MESSAGES, JSON.stringify(messages.slice(-100)));
}

export function loadPrefs(): Record<string, string> {
  try { return JSON.parse(localStorage.getItem(PREFS) || "{}"); } catch { return {}; }
}

export function savePrefs(prefs: Record<string, string>) {
  localStorage.setItem(PREFS, JSON.stringify(prefs));
}
