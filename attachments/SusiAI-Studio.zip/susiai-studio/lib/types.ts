export type Mode = "chat" | "code" | "image" | "video";

export type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
};

export type Project = {
  id: string;
  name: string;
  updatedAt: number;
};
