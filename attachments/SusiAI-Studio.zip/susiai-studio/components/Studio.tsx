"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Bot, Code2, FolderOpen, ImageIcon, MessageSquare, Film,
  Music2, Brain, History, Settings, HelpCircle, Plus, Paperclip,
  Send, Mic, Sparkles, Play, Bug, TestTube2, Wrench, Rocket,
  Copy, Check, WandSparkles, Download, ChevronRight
} from "lucide-react";
import type { Message, Mode, Project } from "@/lib/types";
import { loadMessages, loadPrefs, loadProjects, saveMessages, savePrefs, saveProjects } from "@/lib/storage";

const modes: {id: Mode; label: string; icon: React.ReactNode}[] = [
  {id:"chat",label:"Chat",icon:<MessageSquare size={18}/>},
  {id:"code",label:"Code",icon:<Code2 size={18}/>},
  {id:"image",label:"Image Studio",icon:<ImageIcon size={18}/>},
  {id:"video",label:"Video Studio",icon:<Film size={18}/>},
];

export default function Studio() {
  const [mode, setMode] = useState<Mode>("chat");
  const [messages, setMessages] = useState<Message[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [prefs, setPrefs] = useState<Record<string,string>>({});
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [imageUrl, setImageUrl] = useState("");
  const [video, setVideo] = useState("");
  const [copied, setCopied] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    setMessages(loadMessages());
    setProjects(loadProjects());
    setPrefs(loadPrefs());
  }, []);

  useEffect(() => saveMessages(messages), [messages]);
  useEffect(() => saveProjects(projects), [projects]);
  useEffect(() => savePrefs(prefs), [prefs]);

  const title = useMemo(() => ({
    chat:"AI Workspace", code:"Code Studio", image:"Image Studio", video:"Video Studio"
  }[mode]), [mode]);

  function newProject() {
    const p: Project = {id: crypto.randomUUID(), name:`Neues Projekt ${projects.length+1}`, updatedAt:Date.now()};
    setProjects([p,...projects]);
  }

  async function sendChat(text = input) {
    if (!text.trim() || busy) return;
    const user: Message = {id:crypto.randomUUID(), role:"user", content:text.trim(), createdAt:Date.now()};
    const next = [...messages, user];
    setMessages(next);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({messages:next, mode, preferences:prefs})
      });
      const data = await res.json();
      const assistant: Message = {id:crypto.randomUUID(), role:"assistant", content:data.text || data.error || "Keine Antwort.", createdAt:Date.now()};
      setMessages([...next, assistant]);
    } catch {
      setMessages([...next,{id:crypto.randomUUID(),role:"assistant",content:"Die Anfrage konnte nicht verarbeitet werden.",createdAt:Date.now()}]);
    } finally { setBusy(false); }
  }

  async function generateImage() {
    if (!input.trim() || busy) return;
    setBusy(true); setImageUrl("");
    try {
      const res = await fetch("/api/image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:input,size:"1024x1024"})});
      const data = await res.json();
      if (data.imageUrl) setImageUrl(data.imageUrl);
      else alert(data.error || "Bild konnte nicht erstellt werden.");
    } finally { setBusy(false); }
  }

  async function generateVideo() {
    if (!input.trim() || busy) return;
    setBusy(true); setVideo("");
    try {
      const res = await fetch("/api/video",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:input,duration:15,aspect:"16:9"})});
      const data = await res.json();
      setVideo(data.storyboard || data.error || "");
    } finally { setBusy(false); }
  }

  async function submit() {
    if (mode === "image") return generateImage();
    if (mode === "video") return generateVideo();
    return sendChat();
  }

  function copyText(text:string) {
    navigator.clipboard?.writeText(text);
    setCopied(true); setTimeout(()=>setCopied(false),1200);
  }

  return (
    <main className="shell">
      <aside className={`sidebar ${mobileNav ? "open":""}`}>
        <div className="brand"><div className="brandMark"><Sparkles size={19}/></div><span>SusiAI</span><small>STUDIO</small></div>
        <button className="newProject" onClick={newProject}><Plus size={17}/> Neues Projekt</button>
        <nav>
          {modes.map(m=><button key={m.id} className={mode===m.id?"navItem active":"navItem"} onClick={()=>{setMode(m.id);setMobileNav(false)}}>{m.icon}<span>{m.label}</span></button>)}
          <div className="navSep"/>
          <button className="navItem"><FolderOpen size={18}/><span>Projekte</span></button>
          <button className="navItem"><Brain size={18}/><span>Memory</span></button>
          <button className="navItem"><History size={18}/><span>History</span></button>
          <button className="navItem"><Bot size={18}/><span>Agents</span><span className="badge">BETA</span></button>
        </nav>
        <div className="sidebarBottom">
          <button className="navItem"><HelpCircle size={18}/><span>Help Center</span></button>
          <button className="navItem"><Settings size={18}/><span>Settings</span></button>
        </div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <button className="mobileMenu" onClick={()=>setMobileNav(!mobileNav)}>☰</button>
          <div><div className="eyebrow">MULTIMODAL WORKSPACE</div><h1>{title}</h1></div>
          <div className="topActions"><span className="online"><i/> AI Online</span><button>⌘ K</button><button>⚙</button></div>
        </header>

        {mode === "chat" && (
          <div className="chatArea">
            <div className="messages">
              {messages.length===0 && <div className="welcome">
                <div className="orb"><Sparkles size={34}/></div>
                <h2>Was möchtest du erschaffen?</h2>
                <p>Chat, Code, Bilder und Videos — in einem gemeinsamen AI-Workspace.</p>
                <div className="quickGrid">
                  <button onClick={()=>sendChat("Erstelle eine moderne Next.js Landingpage für ein AI-Startup.")}><Code2/><span><b>Website erstellen</b><small>Next.js + TypeScript</small></span></button>
                  <button onClick={()=>setMode("image")}><ImageIcon/><span><b>Bild generieren</b><small>Text → Image</small></span></button>
                  <button onClick={()=>setMode("video")}><Film/><span><b>Video planen</b><small>Prompt → Storyboard</small></span></button>
                  <button onClick={()=>sendChat("Erkläre mir einfach, wie ein AI-Agent mit Tools funktioniert.")}><Bot/><span><b>AI-Agent bauen</b><small>Tools + Workflows</small></span></button>
                </div>
              </div>}
              {messages.map(m=><article className={`message ${m.role}`} key={m.id}>
                <div className="avatar">{m.role==="user"?"DU":"✦"}</div>
                <div className="bubble"><div className="messageRole">{m.role==="user"?"Du":"SusiAI"}</div><div className="prose">{m.content}</div>{m.role==="assistant"&&<button className="copy" onClick={()=>copyText(m.content)}>{copied?<Check size={14}/>:<Copy size={14}/>}</button>}</div>
              </article>)}
              {busy && <div className="typing"><span/><span/><span/> SusiAI arbeitet…</div>}
            </div>
          </div>
        )}

        {mode === "code" && <CodeStudio onSend={sendChat}/>}
        {mode === "image" && <ImageStudio imageUrl={imageUrl} busy={busy} prompt={input} setPrompt={setInput}/>}
        {mode === "video" && <VideoStudio video={video} busy={busy} prompt={input} setPrompt={setInput}/>}

        <div className="composer">
          <div className="composerMain">
            <button title="Datei anhängen"><Paperclip size={19}/></button>
            <textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();submit()}}} placeholder={mode==="image"?"Beschreibe dein Bild…":mode==="video"?"Beschreibe dein Video…":"Frag SusiAI, was du erstellen möchtest…"} />
            <button title="Voice input"><Mic size={19}/></button>
            <button className="send" onClick={submit} disabled={busy || !input.trim()}>{busy?<span className="spinner"/>:<Send size={18}/>}</button>
          </div>
          <div className="composerTools">
            <span>Enter zum Senden · Shift+Enter für neue Zeile</span>
            <span>{mode==="image"?"🎨 Image":mode==="video"?"🎬 Video":"✦ SusiAI"}</span>
          </div>
        </div>
      </section>
    </main>
  );
}

function CodeStudio({onSend}:{onSend:(text:string)=>void}) {
  return <div className="codeStudio">
    <div className="codeFiles"><b>PROJECT</b><div>📁 src</div><div>　📄 app.tsx</div><div>　📄 page.tsx</div><div>　📄 styles.css</div><div>📄 package.json</div><div>📄 README.md</div></div>
    <div className="editor"><div className="editorTop"><span>page.tsx</span><button onClick={()=>onSend("Prüfe den Code in page.tsx auf Fehler und verbessere ihn.")}><WandSparkles size={15}/> AI Fix</button></div><pre>{`export default function Home() {
  return (
    <main className="hero">
      <h1>Build with SusiAI</h1>
      <p>Multimodale AI Creation Platform</p>
      <button>Start creating</button>
    </main>
  );
}`}</pre><div className="terminal"><span>●</span> Ready — run your project or ask SusiAI for a change.</div></div>
    <div className="codeTools"><b>AI TOOLS</b><button onClick={()=>onSend("Erkläre den aktuellen Code einfach.")}><Bot/> Explain</button><button onClick={()=>onSend("Optimiere den aktuellen Code.")}><WandSparkles/> Optimize</button><button onClick={()=>onSend("Erstelle Tests für den aktuellen Code.")}><TestTube2/> Tests</button><button onClick={()=>onSend("Debugge den aktuellen Code.")}><Bug/> Debug</button><button><Play/> Run</button><button><Rocket/> Deploy</button></div>
  </div>;
}

function ImageStudio({imageUrl,busy,prompt,setPrompt}:{imageUrl:string;busy:boolean;prompt:string;setPrompt:(v:string)=>void}) {
  return <div className="creative">
    <div className="creativePanel"><div className="panelTitle"><ImageIcon/> IMAGE GENERATOR</div><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Futuristisches AI-Labor in einer gigantischen Raumstation, cinematic…"/><label>STYLE</label><div className="chips"><button>Cinematic</button><button>3D</button><button>Photorealistic</button><button>Cyberpunk</button></div><label>FORMAT</label><div className="chips"><button onClick={()=>setPrompt(prompt+" | Format 1:1")}>1:1</button><button onClick={()=>setPrompt(prompt+" | Format 16:9")}>16:9</button><button onClick={()=>setPrompt(prompt+" | Format 9:16")}>9:16</button></div><button className="primary" onClick={()=>document.querySelector<HTMLButtonElement>(".send")?.click()} disabled={busy||!prompt.trim()}><Sparkles/> {busy?"Generiere…":"Generate Image"}</button></div>
    <div className="preview">{imageUrl?<><img src={imageUrl} alt="Generated"/><div className="previewActions"><button><Download/> Save</button><button><WandSparkles/> Edit</button></div></>:<div className="emptyPreview"><ImageIcon size={42}/><b>Deine Kreation erscheint hier</b><span>Beschreibe links, was SusiAI erzeugen soll.</span></div>}</div>
  </div>;
}

function VideoStudio({video,busy,prompt,setPrompt}:{video:string;busy:boolean;prompt:string;setPrompt:(v:string)=>void}) {
  return <div className="creative">
    <div className="creativePanel"><div className="panelTitle"><Film/> VIDEO STUDIO</div><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="15 Sekunden Cinematic-Video eines Raumschiffs beim Flug durch eine Galaxie…"/><label>VIDEO</label><div className="chips"><button>16:9</button><button>9:16</button><button>15 sec</button><button>Cinematic</button></div><button className="primary" onClick={()=>document.querySelector<HTMLButtonElement>(".send")?.click()} disabled={busy||!prompt.trim()}><Film/> {busy?"Plane…":"Create Video"}</button></div>
    <div className="preview videoPreview">{video?<><pre>{video}</pre><div className="previewActions"><button><Play/> Preview</button><button><Download/> Export</button></div></>:<div className="emptyPreview"><Film size={42}/><b>Video Workspace</b><span>SusiAI erstellt zuerst Script und Storyboard. Danach kann ein Video-Provider angebunden werden.</span></div>}</div>
  </div>;
}
