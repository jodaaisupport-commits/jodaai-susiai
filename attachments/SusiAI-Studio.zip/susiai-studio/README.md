# SusiAI Studio

Vollständiger Next.js/TypeScript-MVP für eine multimodale AI Development & Creation Platform.

## Enthalten

- 💬 Chat Workspace
- 💻 Code Studio
- 🎨 Image Studio
- 🎬 Video Studio
- 🧠 lokale Preference/Memory-Schicht
- 📁 Projektverwaltung im Browser
- AI-Orchestrator API
- OpenAI Chat/Responses Integration
- OpenAI Image Generation Integration
- Provider-agnostischer Video-Storyboard-Endpunkt
- Responsive Dark/Futuristic UI
- Demo-Modus ohne API-Key

## Voraussetzungen

Node.js 20.9+ wird für aktuelle Next.js-Versionen empfohlen.

## Start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Dann `http://localhost:3000` öffnen.

Ohne `OPENAI_API_KEY` läuft die Oberfläche im Demo-Modus.

Mit Key:
- `/api/chat` nutzt die Responses API.
- `/api/image` nutzt die Image API.
- `/api/video` erzeugt aktuell ein KI-Storyboard. Für echte Video-Generierung wird ein Video-Provider-Adapter benötigt.

## Produktion

Für ein produktives System sollten Authentifizierung, Datenbank, Objekt-Storage, Rate-Limits, Job Queue und ein isolierter Code-Sandbox-Service ergänzt werden.

Die App ist absichtlich so strukturiert, dass diese Dienste später ohne Umbau der UI ergänzt werden können.
