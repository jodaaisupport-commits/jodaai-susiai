import { NextRequest } from "next/server";
import { getOpenAI } from "@/lib/openai";

export async function POST(req: NextRequest) {
  const { prompt, size = "1024x1024" } = await req.json();
  if (!prompt?.trim()) return Response.json({ error: "Prompt fehlt." }, { status: 400 });

  const client = getOpenAI();
  if (!client) {
    return Response.json({
      demo: true,
      imageUrl: `https://placehold.co/1024x1024/10131a/ffffff?text=${encodeURIComponent("SusiAI Demo")}`
    });
  }

  const result = await client.images.generate({
    model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2",
    prompt: prompt.trim(),
    size
  });

  const item = result.data?.[0];
  if (!item) return Response.json({ error: "Keine Bildantwort erhalten." }, { status: 502 });

  if ("b64_json" in item && item.b64_json) {
    return Response.json({ demo: false, imageUrl: `data:image/png;base64,${item.b64_json}` });
  }
  return Response.json({ demo: false, imageUrl: item.url || null });
}
