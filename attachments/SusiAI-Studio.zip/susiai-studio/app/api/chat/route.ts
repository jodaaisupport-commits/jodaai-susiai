import { NextRequest } from "next/server";
import { getOpenAI } from "@/lib/openai";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const messages = Array.isArray(body.messages) ? body.messages : [];
  const mode = body.mode || "chat";
  const prefs = body.preferences || {};

  const client = getOpenAI();

  if (!client) {
    const demo = `Demo-Modus aktiv. Ich habe deine Anfrage im Modus "${mode}" erhalten.

Installiere einen API-Key in .env.local, um echte Modellantworten zu aktivieren.

Für Code kann ich dann Fehler analysieren, erklären und Dateien entwerfen. Für Image/Video werden die jeweiligen Generierungs-Workflows verwendet.`;
    return Response.json({ text: demo, demo: true });
  }

  const system = `Du bist SusiAI Studio, ein hilfreicher multimodaler AI-Assistent.
Aktueller Modus: ${mode}.
Antworte auf Deutsch, außer der Nutzer verlangt eine andere Sprache.
Bei Code: liefere robuste, moderne Beispiele und erkläre Fehler einfach.
Bei Bild/Video: optimiere Prompts und strukturiere kreative Anforderungen.
Nutze diese Nutzerpräferenzen, wenn vorhanden: ${JSON.stringify(prefs)}.`;

  const input = messages.slice(-20).map((m: {role:string;content:string}) => ({
    role: m.role,
    content: m.content
  }));

  const response = await client.responses.create({
    model: process.env.OPENAI_CHAT_MODEL || "gpt-5.6-luna",
    instructions: system,
    input
  });

  return Response.json({ text: response.output_text, demo: false });
}
