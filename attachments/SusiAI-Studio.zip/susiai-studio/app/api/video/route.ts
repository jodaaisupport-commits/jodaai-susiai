import { NextRequest } from "next/server";
import { getOpenAI } from "@/lib/openai";

export async function POST(req: NextRequest) {
  const { prompt, duration = 10, aspect = "16:9" } = await req.json();
  if (!prompt?.trim()) return Response.json({ error: "Video-Prompt fehlt." }, { status: 400 });

  // Provider-agnostic MVP: generates a production-ready storyboard.
  // A real video provider can be connected here without changing the UI.
  const client = getOpenAI();
  if (client) {
    const r = await client.responses.create({
      model: process.env.OPENAI_CHAT_MODEL || "gpt-5.6-luna",
      instructions: "Erstelle ein präzises Kurzvideo-Storyboard auf Deutsch. Gib 4 Szenen, Kamera, Bewegung, Bildinhalt, Voiceover und Musikhinweis aus.",
      input: `Video-Prompt: ${prompt}\nDauer: ${duration} Sekunden\nFormat: ${aspect}`
    });
    return Response.json({ demo: false, storyboard: r.output_text });
  }

  return Response.json({
    demo: true,
    storyboard: `VIDEO STORYBOARD

Format: ${aspect}
Dauer: ${duration}s

Szene 1 — Establishing Shot
Breite Kamerafahrt, Umgebung vorstellen.

Szene 2 — Hauptaktion
Dynamische Bewegung, Fokus auf das zentrale Motiv.

Szene 3 — Detail
Nahaufnahme mit kontrollierter Kamerabewegung.

Szene 4 — Finale
Cinematic Wide Shot mit sauberem Outro.

Voiceover:
„Willkommen in einer neuen Welt.“

Musik:
Cinematic, futuristisch, langsam ansteigend.`
  });
}
