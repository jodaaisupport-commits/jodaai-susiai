import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SusiAI Studio",
  description: "Multimodal AI development and creation workspace"
};

export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
